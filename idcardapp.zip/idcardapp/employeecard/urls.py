from django.urls import path

from . import views

app_name = "employeecard"
urlpatterns=[
    path('',views.index),
    path('giri/',views.giri),
    path('abhijith/', views.abhijeet),
    path('davis/', views.davis),
    path('anjana/', views.anjana),
    path('manjusree/', views.manjusree),
    path('anudev/', views.anudev),
    path('aadel/', views.aadel),
    path('nideesh/', views.nideesh),
    ]
