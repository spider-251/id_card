from django.shortcuts import render, redirect
from django.http import HttpResponse
# Create your views here.


def index(request):
    return HttpResponse("Hello everyone")

def giri(request):
    return render(request,'giri.html')

def abhijeet(request):
    return render(request,'abhijeet.html')

def davis(request):
    return render(request,'davis.html')

def nideesh(request):
    return render(request,'nideesh.html')

def anjana(request):
    return render(request,'anjana.html')

def manjusree(request):
    return render(request,'manjusree.html')

def anudev(request):
    return render(request,'anudev.html')

def aadel(request):
    return render(request,'aadel.html')
